#include <iostream> 

void display(int sum){
  std::cout << "Sum = " << sum << std::endl;
}
