int buffer[8];
void input(int buffer[8]);
