#pragma once
#include "gpu.h" // display()

void compute(int(&buffer)[8]);