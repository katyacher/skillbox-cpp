#include "ram.h"

void input(int buffer[8]){
  
}