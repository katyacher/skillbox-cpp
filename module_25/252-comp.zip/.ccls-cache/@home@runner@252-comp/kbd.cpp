#include "kbd.h"

void input(int(&buffer)[8])
{
    for (int i = 0; i < 8; i++)
    {
        std::cout << "Enter number #" << i+1 << ": ";
        std::cin >> buffer[i];
    }
}