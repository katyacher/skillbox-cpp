#include "disk.h"

void save(int(&buffer)[8])
{
    std::ofstream data("data.txt", std::ios::binary);
    if (data.is_open()){
        data.write((char*)&buffer, sizeof(buffer));
    } else{
        std::cout << "File not open." << std::endl;
    }
    data.close();
}

void load(int(&buffer)[8])
{
    std::ifstream data("data.txt", std::ios::binary);
    if (data.is_open()){
        data.read((char*)&buffer, sizeof(buffer));
    } else{
        std::cout << "File not open." << std::endl;
    }
    data.close();
}