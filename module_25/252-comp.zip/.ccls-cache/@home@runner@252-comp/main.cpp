#include<string>
#include "ram.h"
#include "cpu.h"
#include "kbd.h"
#include "gpu.h"
#include "disk.h"


int main()
{
    std::string command;

    while (command != "exit"){
        std::cout << "Enter command: ";
        std::cin >> command;
        if (command == "exit"){
            break;
        } else if (command == "sum"){
            compute(buffer);
        } else if (command == "save"){
            save(buffer);
        } else if (command == "load"){
            load(buffer);
        } else if (command == "input"){
            input(buffer);
        } else if (command == "display"){
            display(buffer);
        } else {
            std::cout << "Unknown commad." << std::endl;
        }
    }
    return 0;
}