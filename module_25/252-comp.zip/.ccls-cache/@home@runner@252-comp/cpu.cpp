#include "cpu.h"

void compute(int(&buffer)[8])
{
    int sum = 0;
    for (int i = 0; i < 8; i++)
    {
        sum += buffer[i];
    }

  display(sum);
}